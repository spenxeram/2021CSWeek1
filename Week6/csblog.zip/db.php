<?php
$host = "localhost";
$user = "root";
$pw = "";
$db = "itecblog2021_2";

// #1: create the conn object
$conn = new mysqli($host, $user, $pw, $db);
