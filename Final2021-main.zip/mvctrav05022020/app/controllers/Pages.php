<?php

class Pages extends Controller {


}
