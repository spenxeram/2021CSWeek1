<?php
include APPROOT . "/views/inc/header.php";
 ?>
<div class="jumbotron">
  <div class="container">
  <h1>
  User registration
</h1>

  </div>
</div>
<div class="container">

</div>

<?php
include APPROOT . "/views/inc/footer.php";
 ?>
