<?php
/*
* PDO Database class
*/

class Database {


}
