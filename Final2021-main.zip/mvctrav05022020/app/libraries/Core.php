<?php
/*
* App Core Class
* Creates URL and loads core Controller
* Url format - /controller/method/params
*/

class Core {

}
